<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use App\Slider;
use App\Review;
use App\Partner;
use App\Agent;
use App\Country;

class HomeController extends Controller {

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $sliders = Slider::with('images')->get();
        $reviews = Review::all();
        $partners = Partner::all();
        $agents = Agent::all();
        $countries = Country::has('agents')->get();
        return view("front.index", compact('sliders', 'reviews', 'partners', 'agents', 'countries'));
    }

    public function lang() {
        return Redirect::back();
    }

    public function search_agent($id) {
        if ($id != 0) {
            $agents = Agent::where("country_id", $id)->get();
        } else {
            $agents = Agent::all();
        }
        echo json_encode($agents);
        die();
    }

}
