<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\City;
use App\Country;
use App\Hotel;
use App\Feature;
use App\Hotelslider;
use App\Reservation;
use Validator;

/**
 * Description of HotelsController
 *
 * @author mhmudhsham
 */
class HotelsController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $hotels = Hotel::orderBy('id', 'desc')->get();
        return view('admin.hotels.index', compact("hotels"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        $countries = Country::all();
        $features = Feature::all();
        return view('admin.hotels.add', compact('countries', 'features'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
//        dd($request->all());
        $rules['image'] = 'image|mimes:jpeg,jpg,bmp,png|max:100000';
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $hotels = new Hotel;
        $hotels->title_ar = $request->title_ar;
        $hotels->title_en = $request->title_en;
        $hotels->title_ur = $request->title_ur;
        $hotels->content_ar = $request->content_ar;
        $hotels->content_en = $request->content_en;
        $hotels->content_ur = $request->content_ur;
        $hotels->keywords_ar = $request->keywords_ar;
        $hotels->keywords_en = $request->keywords_en;
        $hotels->keywords_ur = $request->keywords_ur;
        $hotels->description_ar = $request->description_ar;
        $hotels->description_en = $request->description_en;
        $hotels->description_ur = $request->description_ur;
        $hotels->country_id = $request->country_id;
        $hotels->city_id = $request->city_id;
        $hotels->features = json_encode($request->features);

        if (!empty($request->image)) {
            $file = $request->image;
            $filename = str_random(6) . '_' . time() . '_' . $file->getClientOriginalName();
            $path = 'images/hotels';
            $file->move($path, $filename);
            $hotels->image = $path . '/' . $filename;
        }
        $hotels->save();
        //return redirect()->route('sliders-web');
        return redirect()->route('admin_hotels');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        $features = Feature::all();
        $edit = Hotel::find($id);
        $selected_features = $edit->features;
        $cities = City::where("country_id", $edit->country_id)->get();
        $countries = Country::all();
        return view('admin.hotels.edit', compact("id", 'edit', 'cities', 'countries', 'features', 'selected_features'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
//        dd($request->all());
        $rules['image'] = 'image|mimes:jpeg,jpg,bmp,png|max:100000';
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $hotels = Hotel::find((int) $id);

        $hotels->title_ar = $request->title_ar;
        $hotels->title_en = $request->title_en;
        $hotels->title_ur = $request->title_ur;
        $hotels->content_ar = $request->content_ar;
        $hotels->content_en = $request->content_en;
        $hotels->content_ur = $request->content_ur;
        $hotels->keywords_ar = $request->keywords_ar;
        $hotels->keywords_en = $request->keywords_en;
        $hotels->keywords_ur = $request->keywords_ur;
        $hotels->description_ar = $request->description_ar;
        $hotels->description_en = $request->description_en;
        $hotels->description_ur = $request->description_ur;
        $hotels->country_id = $request->country_id;
        $hotels->city_id = $request->city_id;
        $hotels->features = json_encode($request->features);

        if (!empty($request->image)) {
            $file = $request->image;
            $filename = str_random(6) . '_' . time() . '_' . $file->getClientOriginalName();
            $path = 'images/hotels';
            $file->move($path, $filename);
            $hotels->image = $path . '/' . $filename;
        }
        $hotels->save();
        return redirect()->route('admin_hotels');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        $hotels = Hotel::destroy((int) $id);
        $data = null;
        if ($hotels) {
            $data['type'] = "success";
            $data['message'] = "تم الحذف بنجاح";
        } else {
            $data['type'] = "error";
            $data['message'] = "لم يتم الحذف";
        }
        echo json_encode($data);
        die();
    }

    public function getCitiesByCountry($country_id) {
        $cities = City::where("country_id", $country_id)->get();
        echo json_encode($cities);
        die();
    }

    public function slider($id) {
        $slider = Hotelslider::where("hotel_id", $id)->get();
        return view('admin.hotels.slider', compact('slider', 'id'));
    }

    public function store_slider(Request $request) {
        $id = $request->hotel_id;
        $images = count($request->image);
        foreach (range(0, $images) as $index) {
            $rules['image.' . $index] = 'image|mimes:jpeg,jpg,bmp,png|max:2000';
        }
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        foreach ($request->image as $image) {
            $slider = new Hotelslider;
            $slider->hotel_id = $request->hotel_id;
            if (!empty($image)) {
                $file = $image;
                $filename = str_random(6) . '_' . time() . '_' . $file->getClientOriginalName();
                $path = 'images/hotels/images';
                $file->move($path, $filename);
                $slider->image = $path . '/' . $filename;
            }
            $slider->save();
        }
        return redirect(url('/admin/hotels/slider/' . $id));
    }

    public function deleteslider($id) {
        $slider = Hotelslider::destroy((int) $id);
        $data = null;
        if ($slider) {
            $data['type'] = "success";
            $data['message'] = "تم الحذف بنجاح";
        } else {
            $data['type'] = "error";
            $data['message'] = "لم يتم الحذف";
        }
        echo json_encode($data);
        die();
    }

    public function reservations() {
        $reservations = Reservation::with("room")->with('hotel')->get();
        return view('admin.hotels.reservations', compact('reservations'));
    }

}
