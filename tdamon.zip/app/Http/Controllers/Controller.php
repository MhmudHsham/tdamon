<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Setting;

class Controller extends BaseController {

    use AuthorizesRequests,
        DispatchesJobs,
        ValidatesRequests;

    public $_settings;

    public function __construct() {
        $settings_all = Setting::all();
        $new_array = null;
        foreach ($settings_all as $one) {
            $new_array[$one->key] = $one->value;
        }
        $this->_settings = (object) $new_array;
        view()->share("settings", $this->_settings);
    }

}
