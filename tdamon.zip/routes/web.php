<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Auth::routes();
Route::group(['middleware' => 'auth'], function () {
// Admin area
    Route::get('admin', "admin\AdminController@index");
// sliders  admin
    Route::get('admin/sliders', "admin\SlidersController@index")->name("admin_sliders");
    Route::get('admin/sliders/add', "admin\SlidersController@create");
    Route::post('admin/sliders/store', "admin\SlidersController@store");
    Route::get('admin/sliders/edit/{id}', "admin\SlidersController@edit");
    Route::post('admin/sliders/update/{id}', "admin\SlidersController@update");
    Route::get('admin/sliders/delete/{id}', "admin\SlidersController@destroy");
    Route::get('admin/sliders/slider/{id}', "admin\SlidersController@slider")->name("sliders_slider");
    Route::post('admin/sliders/store_slider', "admin\SlidersController@store_slider");
    Route::get('admin/sliders/deleteslider/{id}', "admin\SlidersController@deleteslider");

// categories admin
    Route::get('admin/categories', "admin\CategoriesController@index")->name("admin_categories");
    Route::get('admin/categories/add', "admin\CategoriesController@create");
    Route::post('admin/categories/store', "admin\CategoriesController@store");
    Route::get('admin/categories/edit/{id}', "admin\CategoriesController@edit");
    Route::post('admin/categories/update/{id}', "admin\CategoriesController@update");
    Route::get('admin/categories/delete/{id}', "admin\CategoriesController@destroy");

// services admin
    Route::get('admin/services', "admin\ServicesController@index")->name("admin_services");
    Route::get('admin/services/add', "admin\ServicesController@create");
    Route::post('admin/services/store', "admin\ServicesController@store");
    Route::get('admin/services/edit/{id}', "admin\ServicesController@edit");
    Route::post('admin/services/update/{id}', "admin\ServicesController@update");
    Route::get('admin/services/delete/{id}', "admin\ServicesController@destroy");

// news admin
    Route::get('admin/news', "admin\NewsController@index")->name("admin_news");
    Route::get('admin/news/add', "admin\NewsController@create");
    Route::post('admin/news/store', "admin\NewsController@store");
    Route::get('admin/news/edit/{id}', "admin\NewsController@edit");
    Route::post('admin/news/update/{id}', "admin\NewsController@update");
    Route::get('admin/news/delete/{id}', "admin\NewsController@destroy");

// agents admin
    Route::get('admin/agents', "admin\AgentsController@index")->name("admin_agents");
    Route::get('admin/agents/add', "admin\AgentsController@create");
    Route::post('admin/agents/store', "admin\AgentsController@store");
    Route::get('admin/agents/edit/{id}', "admin\AgentsController@edit");
    Route::post('admin/agents/update/{id}', "admin\AgentsController@update");
    Route::get('admin/agents/delete/{id}', "admin\AgentsController@destroy");

// reviews admin
    Route::get('admin/reviews', "admin\ReviewsController@index")->name("admin_reviews");
    Route::get('admin/reviews/add', "admin\ReviewsController@create");
    Route::post('admin/reviews/store', "admin\ReviewsController@store");
    Route::get('admin/reviews/edit/{id}', "admin\ReviewsController@edit");
    Route::post('admin/reviews/update/{id}', "admin\ReviewsController@update");
    Route::get('admin/reviews/delete/{id}', "admin\ReviewsController@destroy");

// agents admin
    Route::get('admin/partners', "admin\PartnersController@index")->name("admin_partners");
    Route::get('admin/partners/add', "admin\PartnersController@create");
    Route::post('admin/partners/store', "admin\PartnersController@store");
    Route::get('admin/partners/edit/{id}', "admin\PartnersController@edit");
    Route::post('admin/partners/update/{id}', "admin\PartnersController@update");
    Route::get('admin/partners/delete/{id}', "admin\PartnersController@destroy");

// agents admin
    Route::get('admin/gallery', "admin\GalleryController@index")->name("admin_gallery");
    Route::get('admin/gallery/add', "admin\GalleryController@create");
    Route::post('admin/gallery/store', "admin\GalleryController@store");
    Route::get('admin/gallery/edit/{id}', "admin\GalleryController@edit");
    Route::post('admin/gallery/update/{id}', "admin\GalleryController@update");
    Route::get('admin/gallery/delete/{id}', "admin\GalleryController@destroy");


// countries admin
    Route::get('admin/countries', "admin\CountriesController@index")->name("admin_countries");
    Route::get('admin/countries/add', "admin\CountriesController@create");
    Route::post('admin/countries/store', "admin\CountriesController@store");
    Route::get('admin/countries/edit/{id}', "admin\CountriesController@edit");
    Route::post('admin/countries/update/{id}', "admin\CountriesController@update");
    Route::get('admin/countries/delete/{id}', "admin\CountriesController@destroy");

// cities
    Route::get('admin/cities/{id}', "admin\CitiesController@index");
    Route::get('admin/cities/add/{id}', "admin\CitiesController@create");
    Route::post('admin/cities/store/{id}', "admin\CitiesController@store");
    Route::get('admin/cities/edit/{id}', "admin\CitiesController@edit");
    Route::post('admin/cities/update/{id}', "admin\CitiesController@update");
    Route::get('admin/cities/delete/{id}', "admin\CitiesController@destroy");


// sightseeing
    Route::get('admin/sightseeing/{id}', "admin\SightseeingController@index");
    Route::get('admin/sightseeing/add/{id}', "admin\SightseeingController@create");
    Route::post('admin/sightseeing/store/{id}', "admin\SightseeingController@store");
    Route::get('admin/sightseeing/edit/{id}', "admin\SightseeingController@edit");
    Route::post('admin/sightseeing/update/{id}', "admin\SightseeingController@update");
    Route::get('admin/sightseeing/delete/{id}', "admin\SightseeingController@destroy");


    // start hotels area
// rooms
    Route::get('admin/rooms', "admin\RoomsController@index")->name("admin_rooms");
    Route::get('admin/rooms/add', "admin\RoomsController@create");
    Route::post('admin/rooms/store', "admin\RoomsController@store");
    Route::get('admin/rooms/edit/{id}', "admin\RoomsController@edit");
    Route::post('admin/rooms/update/{id}', "admin\RoomsController@update");
    Route::get('admin/rooms/delete/{id}', "admin\RoomsController@destroy");


// features
    Route::get('admin/features', "admin\FeaturesController@index")->name("admin_features");
    Route::get('admin/features/add', "admin\FeaturesController@create");
    Route::post('admin/features/store', "admin\FeaturesController@store");
    Route::get('admin/features/edit/{id}', "admin\FeaturesController@edit");
    Route::post('admin/features/update/{id}', "admin\FeaturesController@update");
    Route::get('admin/features/delete/{id}', "admin\FeaturesController@destroy");

// hotels
    Route::get('admin/hotels', "admin\HotelsController@index")->name("admin_hotels");
    Route::get('admin/hotels/add', "admin\HotelsController@create");
    Route::post('admin/hotels/store', "admin\HotelsController@store");
    Route::get('admin/hotels/edit/{id}', "admin\HotelsController@edit");
    Route::post('admin/hotels/update/{id}', "admin\HotelsController@update");
    Route::get('admin/hotels/delete/{id}', "admin\HotelsController@destroy");
    Route::get('admin/hotels/getCitiesByCountry/{id}', "admin\HotelsController@getCitiesByCountry");
    Route::get('admin/hotels/slider/{id}', "admin\HotelsController@slider")->name("hotels_slider");
    Route::post('admin/hotels/store_slider', "admin\HotelsController@store_slider");
    Route::get('admin/hotels/deleteslider/{id}', "admin\HotelsController@deleteslider");
    Route::get('admin/hotels/reservations', "admin\HotelsController@reservations");



    // end hotels area
// settings
    Route::get('admin/settings', "admin\SettingsController@index")->name("admin_settings");
    Route::post('admin/settings/update', "admin\SettingsController@update");

// messages
    Route::get('admin/contacts', "admin\ContactsController@index")->name("admin_contact");

// subscribers
    Route::get('admin/subscribers', "admin\SubscribersController@index")->name("admin_subscribers");
});

#######################################################################################################
// front area
// generals
Route::get('/', "HomeController@index");
Route::get('/search_agent/{id}', "HomeController@search_agent");

// services
Route::get('/services', 'ServicesController@index');
Route::get('/services/details/{id}/{title}', 'ServicesController@details');

// partners
Route::get('/partners', "PartnersController@index");

// conatct us
Route::get('/contact', 'ContactsController@index');
Route::post('/contact/send', 'ContactsController@send');


// language area
Route::get('/lang/{lang}', 'HomeController@lang')->name("lang");
