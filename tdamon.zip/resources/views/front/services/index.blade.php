@extends('front.layout')
@section('content')
<div class="page-title-container">
    <div class="container">
        <div class="page-title pull-left">
            <h2 class="entry-title">Services</h2>
        </div>
        <ul class="breadcrumbs pull-right">
            <li><a href="{{ url('/') }}">Home</a></li>

            <li class="active">Services</li>
        </ul>
    </div>
</div>

<section id="content">
    <div class="container">
        <div id="main">

            <div class="large-block row image-box style2">
                @foreach($services as $one)
                <div class="col-md-6 pull-left">
                    <article class="box">
                        <figure>
                            <a href="{{ url('/services/details/'.$one->id . "/" . str_replace(' ', '-', $one->title_en)) }}" title=""><img src="{{ asset($one->image) }}" alt="{{ $one->title_en }}" title="{{ $one->title_en }}" style="height: 177px;" /></a>
                        </figure>
                        <div class="details">
                            <h4>{{ $one->title_en }}</h4>
                            <p>{{ mb_substr($one->content_en, 0, 200) }}</p>
                            <a href="{{ url('/services/details/'.$one->id . "/" . str_replace(' ', '-', $one->title_en)) }}" title="{{ $one->title_en }}" class="button btn-mini">More</a>
                        </div>
                    </article>
                </div>
                @endforeach
            </div>

        </div>
    </div>
</section>
@stop