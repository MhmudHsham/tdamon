<header id="header" class="navbar-static-top">

    <div class="topnav hidden-xs">
        <div class="container-fluid">
            <nav class="tg-infonav">
                <ul>
                    <li>
                        <i><img src="{{asset('front/images/icons/icon-01.png')}}" alt="image destinations"></i>
                        <span> 2-123-321-6543</span>
                    </li>
                    <li>
                        <i><img src="{{asset('front/images/icons/icon-02.png')}}" alt="image destinations"></i>
                        <span>Group Booking
                            <a href="javascript:void(0);">Send Request Now</a></span>
                    </li>
                </ul>
            </nav>
            <div class="tg-addnavcartsearch">
                <nav class="tg-addnav">
                    <ul>
                        <li><a href="{{ url('/contact') }}">Contact Us</a></li>
                        <li><a href="?page=about_en">About</a></li>
                    </ul>
                </nav>
                <nav class="tg-cartsearch">
                    <ul>
                        <li>
                            <a href="{{ route('lang', ['lang' => 'ar']) }}">العربية</a>

                        </li>
                        <li>
                            <a href="{{ route('lang', ['lang' => 'ur']) }}">الأردية </a>

                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <img src="{{asset('front/images/icons/icon-04.png')}}" alt="image destinations">
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <div class="main-header">

        <a href="#mobile-menu-01" data-toggle="collapse" class="mobile-menu-toggle">
            Main Menu
        </a>

        <div class="container">
            <h1 class="logo navbar-brand">
                <a href="{{ url('/') }}" title="{{ $settings->site_title_en }}">
                    <img src="{{asset('front/images/logo.png')}}" alt="{{ $settings->site_title_en }}" />
                </a>
            </h1>

            <nav id="main-menu" role="navigation">
                <ul class="menu">
                    <li class="current-menu-item hvr-pulse"><a href="{{ url('/') }}">Home</a></li>
                    <li class="hvr-pulse"><a href="{{ url('/about') }}">About</a>

                        <ul>
                            <li><a href="?page=about_en">Vision</a></li>
                            <li><a href="?page=about_en">Mission</a></li>
                            <li><a href="?page=about_en">Target</a></li>

                        </ul>
                    </li>
                    <li class="hvr-pulse menu-item-has-children"><a href="javascript:void(0);">Shrines</a>
                        <ul>
                            <li><a href="?page=citys_en">Makkah</a></li>
                            <li><a href="?page=citys_en">Madina El Monawara</a></li>

                        </ul>



                    </li>

                    <li class="hvr-pulse"><a href="{{ url('/services') }}">Services</a></li>

                    <li class="hvr-pulse"><a href="?page=program_design_en">Create umrah</a></li>
                    <li class="hvr-pulse"><a href="?page=hotels_en">Hotels</a></li>
                    <li class="hvr-pulse"><a href="?page=programs_en">Umrah Package</a></li>
                    <li class="hvr-pulse menu-item-has-children"><a href="javascript:void(0);">Ehgezly</a>

                        <ul>
                            <li><a href="#">World Hotels</a></li>
                            <li><a href="#">Umroh Plus</a></li>

                        </ul>

                    </li>

                    <li class="hvr-pulse"><a href="{{ url('/partners') }}">Partners</a></li>

                    <li class="hvr-pulse"><a href="{{ url('/contact') }}">Contact</a></li>

                </ul>
            </nav>
        </div>

        <nav id="mobile-menu-01" class="mobile-menu collapse">
            <ul id="mobile-primary-menu" class="menu">

                <li class="hvr-pulse"><a href="{{ url('/') }}">Home</a></li>
                <li class="hvr-pulse"><a href="{{ url('/about') }}">About</a>
                    <ul>
                        <li><a href="?page=about_en">Vision</a></li>
                        <li><a href="?page=about_en">Mission</a></li>
                        <li><a href="?page=about_en">Target</a></li>

                    </ul>
                </li>
                <li class="hvr-pulse menu-item-has-children"><a href="javascript:void(0);">Shrines</a>
                    <ul>
                        <li><a href="?page=citys_en">Makkah</a></li>
                        <li><a href="?page=citys_en">Madina El Monawara</a></li>
                    </ul>
                </li>
                <li class="hvr-pulse"><a href="{{ url('/services') }}">Services</a></li>
                <li class="hvr-pulse"><a href="?page=program_design_en">Create umrah</a></li>
                <li class="hvr-pulse"><a href="?page=hotels_en">Hotels</a></li>

                <li class="hvr-pulse"><a href="?page=programs_en">Umrah Package</a></li>
                <li class="hvr-pulse menu-item-has-children"><a href="javascript:void(0);">Ehgezly</a>

                    <ul>
                        <li><a href="#">World Hotels</a></li>
                        <li><a href="#">Umroh Plus</a></li>

                    </ul>

                </li>
                <li class="hvr-pulse"><a href="{{ url('/partners') }}">Partners</a></li>

                <li class="hvr-pulse"><a href="{{ url('/contact') }}">Contact</a></li>
            </ul>

            <ul class="mobile-topnav container">
                <li><a href="#">حسابى</a></li>
                <li class="ribbon language menu-color-skin">
                    <a href="#" data-toggle="collapse">العربية</a>
                    <ul class="menu mini">
                        <li><a href="?page=index_en" title=" ">ENGLISH</a></li>
                        <li><a href="#" title="">الأردية </a></li>

                    </ul>
                </li>
                <li><a href="#" class="soap-popupbox">الدخول</a></li>
                <li><a href="#" class="soap-popupbox">تسجيل جديد</a></li>

            </ul>
        </nav>
    </div>

</header>
