<!-- Page Title -->
<title>{{ $settings->site_title_en }}</title>
<!-- Meta Tags -->
<meta charset="utf-8">
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="Travelo - Travel, Tour Booking HTML5 Template">
<meta name="author" content="SoapTheme">
@yield('head')
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="{{ $settings->site_logo }}" type="image/x-icon">
<!-- Theme Styles -->
{!! HTML::style('front/css/bootstrap.min.css') !!}
{!! HTML::style('front/css/font-awesome.min.css') !!}
{!! HTML::style('http://fonts.googleapis.com/css?family=Lato:300,400,700') !!}
{!! HTML::style('front/css/animate.min.css') !!}
{!! HTML::style('front/css/style.css') !!}
{!! HTML::style('front/css/color.css') !!}

<!-- Current Page Styles -->
{!! HTML::style('front/js/revolution_slider/css/settings.css') !!}
{!! HTML::style('front/js/revolution_slider/css/style.css') !!}
{!! HTML::style('front/js/jquery.bxslider/jquery.bxslider.css') !!}
{!! HTML::style('front/js/flexslider/flexslider.css') !!}
{!! HTML::style('front/css/jquery.fancybox.css') !!}
{!! HTML::style('front/css/jquery.fancybox-thumbs.css') !!}
<!-- Main Style -->
<!--<link id="main-style" rel="stylesheet" href="css/style.css">-->
<!-- Updated Styles -->
{!! HTML::style('front/css/updates.css') !!}
<!-- Custom Styles -->
{!! HTML::style('front/css/custom_en.css') !!}
<!-- Responsive Styles -->
{!! HTML::style('front/css/responsive.css') !!}

<!-- CSS for IE -->
<!--[if lte IE 9]>
    <link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->


<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
<![endif]-->

<!-- Javascript Page Loader -->
{!! HTML::script('front/js/pace.min.js') !!}
{!! HTML::script('front/js/page-loading.js') !!}
<!--<script type="text/javascript" src="" data-pace-options='{ "ajax": false }'></script>-->