
<div id="live-chat">

    <header class="clearfix">

        <a href="#" class="chat-close">x</a>

        <h4>Sales Chat</h4>

        <span class="chat-message-counter pulse" style="display: block">3</span>

    </header>

    <div class="chat" style="display: none">

        <div class="chat-history">

            <div class="chat-message clearfix">

                <img src="{{asset('front/images/user.png') }}" alt="" width="32" height="32">

                <div class="chat-message-content clearfix">

                    <span class="chat-time">13:35</span>

                    <h5>Employee</h5>

                    <p>Welcome, how can I help you</p>

                </div> <!-- end chat-message-content -->

            </div> <!-- end chat-message -->

            <hr>

            <div class="chat-message clearfix clint_user">

                <img src="{{asset('front/images/user.png') }}" alt="" width="32" height="32">

                <div class="chat-message-content clearfix">

                    <span class="chat-time">13:37</span>

                    <h5>Customer</h5>

                    <p>I want to know how to book Umrah from your site</p>

                </div> <!-- end chat-message-content -->

            </div> <!-- end chat-message -->

            <hr>

            <div class="chat-message clearfix">

                <img src="{{asset('front/images/user.png') }}" alt="" width="32" height="32">

                <div class="chat-message-content clearfix">

                    <span class="chat-time">13:38</span>

                    <h5>Employee</h5>

                    <p>Very simple, I appreciate your presence. You can choose Umrah program now and I am with your presence step by step</p>

                </div> <!-- end chat-message-content -->

            </div> <!-- end chat-message -->

            <hr>

        </div> <!-- end chat-history -->

        <hr>
        <p class="chat-feedback">writing a message now</p>

        <form action="#" method="post">

            <fieldset>

                <input type="text" placeholder="Type your message…" autofocus>

                <!--                <a href="#" class="chatbtn">Send</a>-->
                <input class="chatbtn" type="button" value="Send"  onclick="play()">
                <audio id="audio" src="{{asset('front/message.mp3') }}" ></audio>

            </fieldset>

        </form>

    </div> <!-- end chat -->

</div> <!-- end live-chat -->


<footer id="footer">
    <div class="footer-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-3  pull-left">
                    <h2>About</h2>
                    <p> The vision of the company is to become one of the best tourism companies not at the local level ...
                        The vision of the company is to become one of the best tourism companies not at the local level ...
                    </p>
                    <br />
                    <address class="contact-details">
                        <span class="contact-phone"><i class="soap-icon-phone"></i>2-123-321-6543</span>
                        <br />
                        <a href="#" class="contact-email">info@tadamonel3omra.com</a>
                    </address>
                    <ul class="social-icons clearfix">
                        <li class="twitter"><a title="twitter" href="#" data-toggle="tooltip"><i class="soap-icon-twitter"></i></a></li>
                        <li class="googleplus"><a title="googleplus" href="#" data-toggle="tooltip"><i class="soap-icon-googleplus"></i></a></li>
                        <li class="facebook"><a title="facebook" href="#" data-toggle="tooltip"><i class="soap-icon-facebook"></i></a></li>
                        <li class="linkedin"><a title="linkedin" href="#" data-toggle="tooltip"><i class="soap-icon-linkedin"></i></a></li>
                        <li class="vimeo"><a title="vimeo" href="#" data-toggle="tooltip"><i class="soap-icon-vimeo"></i></a></li>
                        <li class="dribble"><a title="dribble" href="#" data-toggle="tooltip"><i class="soap-icon-dribble"></i></a></li>
                        <li class="flickr"><a title="flickr" href="#" data-toggle="tooltip"><i class="soap-icon-flickr"></i></a></li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3 pull-left">
                    <h2>Important links</h2>
                    <ul class="discover triangle hover row">
                        <li class="active col-xs-6 pull-left"><a href="#">Home</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Shrines</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Services</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Partners</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">News</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Create umrah</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Shrines</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Services</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Partners</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">News</a></li>
                        <li class="col-xs-6 pull-left"><a href="#">Create umrah</a></li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3  pull-left">
                    <h2>latest news</h2>
                    <ul class="travel-news">
                        <li>
                            <div class="thumb">
                                <a href="#">
                                    <img src="{{asset('front/images/news01.png') }}" alt="" width="63" height="63" />
                                </a>
                            </div>
                            <div class="description">
                                <h5 class="s-title"><a href="#">News Title Here</a></h5>
                                <p>There is a textual content here </p>
                                <span class="date">10 Oct, 2017</span>
                            </div>
                        </li>
                        <li>
                            <div class="thumb">
                                <a href="#">
                                    <img src="{{asset('front/images/news02.png') }}" alt="" width="63" height="63" />
                                </a>
                            </div>
                            <div class="description">
                                <h5 class="s-title"><a href="#">News Title Here</a></h5>
                                <p>There is a textual content here </p>
                                <span class="date">10 Oct, 2017</span>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3  pull-left">
                    <h2>Newsletter</h2>
                    <p>Subscribe with us and get all new e-mail</p>
                    <br />
                    <div class="icon-check">
                        <input type="text" class="input-text full-width" placeholder="e-mail" />
                    </div>
                    <br />
                    <div class="col-md-12 text-center">
                        <img src="{{asset('front/images/b_47_225.gif') }}" alt="" />
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="bottom gray-area">
        <div class="container">
            <div class="">
                <a id="back-to-top" href="#" class="animated" data-animation-type="bounce"><i class="soap-icon-longarrow-up circle"></i></a>
            </div>
            <div class="copyright text-center">
                <p>All Rights Reserved ©.2017 | <a target="_blank" href="http://www.mv-is.com/">Powered By MASTER VISION Integrated Solutions </a></p>
            </div>
        </div>
    </div>
</footer>



<!-- Javascript -->
{!! HTML::script('front/js/jquery-1.11.1.min.js') !!}

{!! HTML::script('front/js/jquery.noconflict.js') !!}
{!! HTML::script('front/js/modernizr.2.7.1.min.js') !!}
{!! HTML::script('front/js/jquery-migrate-1.2.1.min.js') !!}
{!! HTML::script('front/js/jquery.placeholder.js') !!}
{!! HTML::script('front/js/jquery-ui.1.10.4.min.js') !!}

<!-- Twitter Bootstrap -->
{!! HTML::script('front/js/bootstrap.min.js') !!}

<!-- load revolution slider scripts -->
{!! HTML::script('front/js/revolution_slider/js/jquery.themepunch.tools.min.js') !!}
{!! HTML::script('front/js/revolution_slider/js/jquery.themepunch.revolution.min.js') !!}

<!-- load BXSlider scripts -->
{!! HTML::script('front/js/jquery.bxslider/jquery.bxslider.min.js') !!}

<!-- Flex Slider -->
{!! HTML::script('front/js/flexslider/jquery.flexslider-min.js') !!}

<!-- parallax -->
{!! HTML::script('front/js/jquery.stellar.min.js') !!}

<!-- waypoint -->
{!! HTML::script('front/js/waypoints.min.js') !!}
{!! HTML::script('front/js/jquery.fancybox.js') !!}

@yield('scripts_pages')


<!-- load page Javascript -->
{!! HTML::script('front/js/theme-scripts.js') !!}
{!! HTML::script('front/js/scripts.js') !!}

<script type="text/javascript">
    tjq(document).ready(function () {
        tjq('.revolution-slider').revolution(
                {
                    sliderType: "standard",
                    sliderLayout: "auto",
                    dottedOverlay: "none",
                    delay: 10000,
                    navigation: {
                        keyboardNavigation: "off",
                        keyboard_direction: "horizontal",
                        mouseScrollNavigation: "off",
                        mouseScrollReverse: "default",
                        onHoverStop: "on",
                        touch: {
                            touchenabled: "on",
                            swipe_threshold: 75,
                            swipe_min_touches: 1,
                            swipe_direction: "horizontal",
                            drag_block_vertical: false
                        }
                        ,
                        arrows: {
                            style: "default",
                            enable: true,
                            hide_onmobile: false,
                            hide_onleave: false,
                            tmp: '',
                            left: {
                                h_align: "left",
                                v_align: "center",
                                h_offset: 20,
                                v_offset: 0
                            },
                            right: {
                                h_align: "right",
                                v_align: "center",
                                h_offset: 20,
                                v_offset: 0
                            }
                        }
                    },
                    visibilityLevels: [1240, 1024, 778, 480],
                    gridwidth: 1170,
                    gridheight: 646,
                    lazyType: "none",
                    shadow: 0,
                    spinner: "spinner4",
                    stopLoop: "off",
                    stopAfterLoops: -1,
                    stopAtSlide: -1,
                    shuffle: "off",
                    autoHeight: "off",
                    hideThumbsOnMobile: "off",
                    hideSliderAtLimit: 0,
                    hideCaptionAtLimit: 0,
                    hideAllCaptionAtLilmit: 0,
                    debugMode: false,
                    fallbacks: {
                        simplifyAll: "off",
                        nextSlideOnWindowFocus: "off",
                        disableFocusListener: false,
                    }
                });
    });
</script>

<script type="text/javascript">
    tjq(document).ready(function () {
        tjq("#price-range").slider({
            range: true,
            min: 0,
            max: 1000,
            values: [100, 800],
            slide: function (event, ui) {
                tjq(".min-price-label").html("$" + ui.values[ 0 ]);
                tjq(".max-price-label").html("$" + ui.values[ 1 ]);
            }
        });
        tjq(".min-price-label").html("SAR" + tjq("#price-range").slider("values", 0));
        tjq(".max-price-label").html("SAR" + tjq("#price-range").slider("values", 1));

        tjq("#rating").slider({
            range: "min",
            value: 40,
            min: 0,
            max: 50,
            slide: function (event, ui) {

            }
        });
    });
</script>
<script>
    function play() {
        var audio = document.getElementById("audio");
        audio.play();
    }
</script>
<script>
    tjq(document).ready(function () {
        tjq(".galleryimg").fancybox({
            'transitionIn': 'elastic',
            'transitionOut': 'elastic',
            type: 'image',
            'allowfullscreen': true,

        });
    });
</script>
<input type="hidden" id="utl" value="{{ url('/') }}" />

<script type="text/javascript">
    tjq(document).ready(function () {
        var utl = tjq("#utl").val();
        tjq("#search_agent_button").click(function (e) {
            e.preventDefault();
            var current_country = tjq("#agent_country").val();
            tjq.ajax({
                url: "{{ url('/search_agent/') }}" + "/" + current_country,
                type: "get",
                data: {},
                success: function (msg) {
                    console.log(msg);
                    var html = "";
                    var result = JSON.parse(msg);
                    for (var i in result) {
                        html += '<div class="col-md-3 col-xs-6 wkyle">'
                                + '<a href="' + result[i].url + '" target="_blank">'
                                + '<img style="height: 58px;width: 153px;" src="' + utl + '/' + result[i].image + '" alt="' + result[i].title_en + '"  title="' + result[i].title_en + '">'
                                + '</a>'
                                + '</div>';
                    }
                    tjq("#agents_block").html(html);
                }
            });
        });
    });
</script>


