@extends('front.layout')
@section('content')
<div id="slideshow" class="ltr">
    <div class="fullwidthbanner-container">
        <div class="revolution-slider rev_slider" style="height: 0; overflow: hidden;">
            <ul>

                @if(isset($sliders[0]) && !empty($sliders[0]))
                <li data-index="rs-21" data-transition="cube" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="800"  data-thumb="{{asset('front/uploads/revslider1/snapshot/bg1.jpg') }}"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="{{asset($sliders[0]->image) }}"  alt="" title="Slider1"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->

                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption large_bold_white_med   tp-resizeme slidetxt"
                         id="slide-21-layer-1"
                         data-x="center"
                         data-y="261"
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:left;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:-50px;opacity:0;s:300;s:300;"
                         data-start="1000"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"


                         style="z-index: 99999;">
                        {{ $sliders[0]->title_en }}
                    </div>


                    @if($sliders[0]->url != "")
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption largewhitebg_button1   tp-resizeme slidetxt"
                         id="slide-21-layer-2"
                         data-x="center"
                         data-y="342"
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:-50px;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:-50px;opacity:0;s:300;s:300;"
                         data-start="1400"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"


                         style="z-index: 6;"><a href="#" class="samem">More ...</a> </div>
                    @endif





                    @if(isset($sliders[0]) && !empty($sliders[0]->images))
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-4"
                         data-x="718"
                         data-y="22"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="y:top;s:1500;e:Power3.easeInOut;"
                         data-transform_out="y:-50px;opacity:0;s:300;s:300;"
                         data-start="2000"
                         data-responsive_offset="on"


                         style="z-index: 8;"><img src="{{asset('front/uploads/revslider1/snapshot/poss8.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-5"
                         data-x="614"
                         data-y="123"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="2300"
                         data-responsive_offset="on"


                         style="z-index: 9;"><img src="{{asset('front/uploads/revslider1/snapshot/poss6.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 6 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-6"
                         data-x="862"
                         data-y="67"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:right;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:50px;opacity:0;s:300;s:300;"
                         data-start="2600"
                         data-responsive_offset="on"


                         style="z-index: 10;"><img src="{{asset('front/uploads/revslider1/snapshot/poss7.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 7 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-7"
                         data-x="823"
                         data-y="109"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="2900"
                         data-responsive_offset="on"


                         style="z-index: 11;"><img src="{{asset('front/uploads/revslider1/snapshot/poss5.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 8 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-8"
                         data-x="706"
                         data-y="337"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="y:bottom;s:1500;e:Power3.easeInOut;"
                         data-transform_out="y:bottom;s:300;s:300;"
                         data-start="3200"
                         data-responsive_offset="on"


                         style="z-index: 12;"><img src="{{asset('front/uploads/revslider1/snapshot/poss4.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 9 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-9"
                         data-x="756"
                         data-y="196"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="3500"
                         data-responsive_offset="on"


                         style="z-index: 13;"><img src="{{asset('front/uploads/revslider1/snapshot/poss3.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 10 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-10"
                         data-x="688"
                         data-y="316"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:-50px;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:-50px;opacity:0;s:300;s:300;"
                         data-start="3800"
                         data-responsive_offset="on"


                         style="z-index: 14;"><img src="{{asset('front/uploads/revslider1/snapshot/small_pos.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 11 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-11"
                         data-x="936"
                         data-y="265"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:right;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:50px;opacity:0;s:300;s:300;"
                         data-start="4100"
                         data-responsive_offset="on"


                         style="z-index: 15;"><img src="{{asset('front/uploads/revslider1/snapshot/poss22.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 12 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-21-layer-12"
                         data-x="862"
                         data-y="362"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="4400"
                         data-responsive_offset="on"


                         style="z-index: 16;"><img src="{{asset('front/uploads/revslider1/snapshot/pos.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>
                    @endif
                </li>
                <!-- SLIDE  -->
                @endif

                <!-- SLIDE  -->
                <li data-index="rs-20" data-transition="boxslide" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="800"  data-thumb="{{asset('front/uploads/revslider1/snapshot/bg.jpg') }}"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="{{asset('front/uploads/revslider1/snapshot/bg.jpg') }}"  alt="" title="Slider1"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->

                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-1"
                         data-x="793"
                         data-y="161"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="500"
                         data-responsive_offset="on"


                         style="z-index: 5;"><img src="{{asset('front/uploads/revslider1/snapshot/pic112.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-2"
                         data-x="727"
                         data-y="273"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="800"
                         data-responsive_offset="on"


                         style="z-index: 6;"><img src="{{asset('front/uploads/revslider1/snapshot/pic1121.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-3"
                         data-x="714"
                         data-y="108"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="1100"
                         data-responsive_offset="on"


                         style="z-index: 7;"><img src="{{asset('front/uploads/revslider1/snapshot/pic1122.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-4"
                         data-x="495"
                         data-y="299"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="1400"
                         data-responsive_offset="on"


                         style="z-index: 8;"><img src="{{asset('front/uploads/revslider1/snapshot/pic1124.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-5"
                         data-x="617"
                         data-y="327"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="1700"
                         data-responsive_offset="on"


                         style="z-index: 9;"><img src="{{asset('front/uploads/revslider1/snapshot/pic1125.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 6 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-6"
                         data-x="513"
                         data-y="67"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="2000"
                         data-responsive_offset="on"


                         style="z-index: 10;"><img src="{{asset('front/uploads/revslider1/snapshot/pic1126.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 7 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-20-layer-7"
                         data-x="712"
                         data-y="181"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:300;s:300;"
                         data-start="2300"
                         data-responsive_offset="on"


                         style="z-index: 11;"><img src="{{asset('front/uploads/revslider1/snapshot/pic112611.png') }}" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>

                    <!-- LAYER NR. 8 -->
                    <div class="tp-caption large_bold_white_med   tp-resizeme slidetxt"
                         id="slide-20-layer-8"
                         data-x="center"
                         data-y="261"
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:left;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:-50px;opacity:0;s:300;s:300;"
                         data-start="2600"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"


                         style="z-index: 12;">Design your Umrah now as easily as<br>
                        Your desires are simply - ease - and speed
                    </div>

                    <!-- LAYER NR. 9 -->
                    <div class="tp-caption largewhitebg_button1   tp-resizeme slidetxt"
                         id="slide-20-layer-9"
                         data-x="center"
                         data-y="342"
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:-50px;opacity:0;s:1500;e:Power3.easeInOut;"
                         data-transform_out="x:-50px;opacity:0;s:300;s:300;"
                         data-start="2900"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"


                         style="z-index: 13;"><a href="#" class="samem">Designed umrah Online</a> </div>

                    <!-- LAYER NR. 10 -->

                </li>
                <!-- SLIDE  -->


            </ul>
        </div>
    </div>
</div>

<section id="content" class="pt0">
    <div class="global-map-area4 section">
        <div class="container">
            <div class="text-center description">
                <h1>Who We Are</h1>
                <p>Hajj and Umrah trips in the concept of our company are not only the leading practices. It is a spiritual journey that purifies the soul, the heart and the body, and we realize the true meaning of our existence in life, so that we can reach the stage of tranquility and good faith in God. The role of our company is to provide all the means of care and welfare, giving our client the opportunity to devote full time to worship with sincerity and kindness ...

                </p>

            </div>
            <br />
            <div class="row">
                <div class="col-md-8 col-xs-12 pull-left">

                    <div class="tab-container style1">
                        <ul class="tabs full-width">
                            <li class="active"><a href="#unlimited-layouts" data-toggle="tab">Our Vision</a></li>
                            <li><a href="#design-inovation" data-toggle="tab">Our Mission</a></li>
                            <li><a href="#best-support" data-toggle="tab">Why Us</a></li>
                            <li><a href="#8-sliders" data-toggle="tab">What We Do ?</a></li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade in active" id="unlimited-layouts">
                                <h4>Our Vision</h4>
                                <p>  </p>

                                <p>Hajj and Umrah trips in the concept of our company are not only the leading practices. It is a spiritual journey that purifies the soul, the heart and the body, and we realize the true meaning of our existence in life, so that we can reach the stage of tranquility and good faith in God. The role of our company is to provide all the means of care and welfare, giving our client the opportunity to devote full time to worship with sincerity and kindness ...

                                </p>

                                <a href="" class="button pull-right">More</a>
                            </div>
                            <div class="tab-pane fade" id="design-inovation">
                                <h4>Our Mission</h4>
                                <p>Hajj and Umrah trips in the concept of our company are not only the leading practices. It is a spiritual journey that purifies the soul, the heart and the body, and we realize the true meaning of our existence in life, so that we can reach the stage of tranquility and good faith in God. The role of our company is to provide all the means of care and welfare, giving our client the opportunity to devote full time to worship with sincerity and kindness ...

                                </p>
                                <a href="#" class="button pull-right">More</a>
                            </div>
                            <div class="tab-pane fade" id="best-support">
                                <h4>لماذا نحن</h4>
                                <p>رحلات الحج و العمرة بمفهوم شركتنا ليست فقط مناسك تؤدي . انما هى رحلة روحانيه تنقى الروح و القلب و الجسد و ندرك فيها المعنى الحقيقى لوجودنا فى الحياة لنصل لمرحلة السكينة و حسن الظن بالله . دور شركتنا  فيها هو توفير كل سبل الرعاية و الرفاهية مما يعطى عميلنا الفرصة كاملة للتفرغ للعبادة باخلاص و احسان …
                                </p>
                                <a href="#" class="button pull-right">المزيد</a>
                            </div>
                            <div class="tab-pane fade" id="8-sliders">
                                <h4>ماذا نفعل؟</h4>
                                <p>رحلات الحج و العمرة بمفهوم شركتنا ليست فقط مناسك تؤدي . انما هى رحلة روحانيه تنقى الروح و القلب و الجسد و ندرك فيها المعنى الحقيقى لوجودنا فى الحياة لنصل لمرحلة السكينة و حسن الظن بالله . دور شركتنا  فيها هو توفير كل سبل الرعاية و الرفاهية مما يعطى عميلنا الفرصة كاملة للتفرغ للعبادة باخلاص و احسان …
                                </p>
                                <a href="#" class="button pull-right">المزيد</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-xs-12 pull-left">

                    <iframe width="100%" height="280" src="https://www.youtube.com/embed/H5gOj8aIFl4" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
    <div class="global-map-area promo-box no-margin parallax" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="content-section description pull-right col-sm-8">
                <div class="table-wrapper hidden-table-sm">
                    <div class="table-cell">
                        <h2 class="m-title">
                            Select the flight, hotels and date required

                            <br /><em>  Now you can design umrah as you want</em>
                        </h2>
                    </div>
                    <div class="table-cell action-section col-md-4  pull-left animated" data-animation-type="fadeInUp">
                        <button class="full-width btn-large">Designed umrah Online</button>
                    </div>
                </div>
            </div>
            <div class="image-container col-sm-4 pull-left">
                <img src="{{ asset('front/images/flight/home/girl.png') }}" alt="" class="animated" data-animation-type="fadeInUp" />
            </div>
        </div>
    </div>
    <div class="section container">
        <div class="row">
            <h2 class="pull-left">Special Offers</h2>
            <div class="col-md-2 buttn mb10 pull-right">
                <button class="full-width btn-large">Booking groups</button>
            </div>
            <div class="col-md-2 pull-right">
                <button class="full-width btn-large">Umrah Package</button>
            </div>
        </div>
        <div class="row image-box hotel listing-style1">
            <div class="col-xs-12 col-sm-6 col-md-3 pull-left">
                <article class="box">
                    <figure class="animated" data-animation-type="fadeInDown" data-animation-delay="0">
                        <a class="hover-effect" href="#" title=""><img width="270" height="161" src="{{ asset('front/images/pro/1.jpg') }}" alt=""></a>
                    </figure>
                    <div class="details">

                        <h4 class="box-title">Umrah Ramadan</h4>
                        <div class="feedback">
                            <span class="price">

                                SAR 360
                            </span>
                            <div title="5 stars" class="five-stars-container" data-toggle="tooltip" data-placement="bottom"><span class="five-stars" style="width: 100%;"></span></div>

                        </div>
                        <p class="description">Best Umrah Al-Sherif Offers Join our distinguished customers and book: Unmatched services</p>
                        <div class="action">
                            <a href="#" class="button btn-small">More</a>
                            <a href="#" class="button btn-small yellow">Book Now</a>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3 pull-left">
                <article class="box">
                    <figure class="animated" data-animation-type="fadeInDown" data-animation-delay="0">
                        <a class="hover-effect" href="#" title=""><img width="270" height="161" src="{{ asset('front/images/pro/2.jpg') }}" alt=""></a>
                    </figure>
                    <div class="details">

                        <h4 class="box-title">Umrah Ramadan</h4>
                        <div class="feedback">
                            <span class="price">

                                SAR 360
                            </span>
                            <div title="5 stars" class="five-stars-container" data-toggle="tooltip" data-placement="bottom"><span class="five-stars" style="width: 100%;"></span></div>

                        </div>
                        <p class="description">Best Umrah Al-Sherif Offers Join our distinguished customers and book: Unmatched services</p>
                        <div class="action">
                            <a href="#" class="button btn-small">More</a>
                            <a href="#" class="button btn-small yellow">Book Now</a>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3 pull-left">
                <article class="box">
                    <figure class="animated" data-animation-type="fadeInDown" data-animation-delay="0">
                        <a class="hover-effect" href="#" title=""><img width="270" height="161" src="{{ asset('front/images/pro/3.jpg') }}" alt=""></a>
                    </figure>
                    <div class="details">

                        <h4 class="box-title">Umrah Ramadan</h4>
                        <div class="feedback">
                            <span class="price">

                                SAR 360
                            </span>
                            <div title="5 stars" class="five-stars-container" data-toggle="tooltip" data-placement="bottom"><span class="five-stars" style="width: 100%;"></span></div>

                        </div>
                        <p class="description">Best Umrah Al-Sherif Offers Join our distinguished customers and book: Unmatched services</p>
                        <div class="action">
                            <a href="#" class="button btn-small">More</a>
                            <a href="#" class="button btn-small yellow">Book Now</a>
                        </div>
                    </div>
                </article>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-3 pull-left">
                <article class="box">
                    <figure class="animated" data-animation-type="fadeInDown" data-animation-delay="0">
                        <a class="hover-effect" href="#" title=""><img width="270" height="161" src="{{ asset('front/images/pro/4.jpg') }}" alt=""></a>
                    </figure>
                    <div class="details">

                        <h4 class="box-title">Umrah Ramadan</h4>
                        <div class="feedback">
                            <span class="price">

                                SAR 360
                            </span>
                            <div title="5 stars" class="five-stars-container" data-toggle="tooltip" data-placement="bottom"><span class="five-stars" style="width: 100%;"></span></div>

                        </div>
                        <p class="description">Best Umrah Al-Sherif Offers Join our distinguished customers and book: Unmatched services</p>
                        <div class="action">
                            <a href="#" class="button btn-small">More</a>
                            <a href="#" class="button btn-small yellow">Book Now</a>
                        </div>
                    </div>
                </article>
            </div>

        </div>
    </div>



    <div class="global-map-area2 mobile-section parallax" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="table-wrapper hidden-table-sm">
                <div class="col-md-6 description section table-cell">
                    <h1>Ehgezly Website</h1>

                    <br>


                    <a class="button btn-extra blue"><i class="soap-icon-hotel-2"></i><span> <em>World Hotels</em></span></a>
                    <a class="button btn-extra blue"><i class="soap-icon-insurance"></i><span><em>Umrah Plus</em></span></a>
                </div>
                <div class="col-md-6 image-wrapper table-cell hidden-sm">
                    <img src="{{ asset('front/images/travelo_site.png') }}" alt="" class="animated" data-animation-type="fadeInUp">
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="container">
            <div class="text-center description block">
                <h1>Hotels</h1>
                <p>Know with us the most important and best hotels in Saudi Arabia </p>
            </div>


            <div class="block image-carousel style2 flexslider ltr" data-animation="slide" data-item-width="370" data-item-margin="30">
                <ul class="slides image-box style1 tour-packages">
                    <li>
                        <article class="box">
                            <figure>
                                <a class="hover-effect" title="" href="#"><img width="270" height="160" alt="" src="{{ asset('front/images/hotel/1.jpg') }}" draggable="false"></a>
                            </figure>
                            <div class="details">

                                <h4 class="box-title">Dar Al Tawhid Intercontinental</h4>
                            </div>
                        </article>
                    </li>
                    <li>
                        <article class="box">
                            <figure>
                                <a class="hover-effect" title="" href="#"><img width="270" height="160" alt="" src="{{ asset('front/images/hotel/2.jpg') }}" draggable="false"></a>
                            </figure>
                            <div class="details">

                                <h4 class="box-title">Dar Al-Eman Intercontinental </h4>
                            </div>
                        </article>
                    </li>
                    <li>
                        <article class="box">
                            <figure>
                                <a class="hover-effect" title="" href="#"><img width="270" height="160" alt="" src="{{ asset('front/images/hotel/3.jpg') }}" draggable="false"></a>
                            </figure>
                            <div class="details">

                                <h4 class="box-title">Dar Al Tawheed Intercontinental </h4>
                            </div>
                        </article>
                    </li>
                    <li>
                        <article class="box">
                            <figure>
                                <a class="hover-effect" title="" href="#"><img width="270" height="160" alt="" src="{{ asset('front/images/hotel/4.jpg') }}" draggable="false"></a>
                            </figure>
                            <div class="details">

                                <h4 class="box-title">ANJUM HOTEL </h4>
                            </div>
                        </article>
                    </li>

                </ul>
            </div>



        </div>
    </div>



    <section class="section  global-map-area2">
        <div class="container">
            <div class="row text-center description block">
                <h1>Our agents around the world</h1>
                <p>Know with our agents around the world to know the agents in your country choose the Bad
                </p>
            </div>


            <div class="row">
                <div class="col-md-4 pull-left">
                    <div class="col-xs-6 col-md-12">

                        <div class="selector mb20">
                            <select id="agent_country" class="full-width">
                                <option value="0">All Countries</option>
                                @foreach($countries as $one)
                                <option value="{{ $one->id }}">{{ $one->title_en }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-12">
                        <button id="search_agent_button" class="full-width btn-large">Search For Agents</button>
                    </div>
                </div>

                <div class="col-md-8 col-xs-12 pull-left" id="agents_block">

                    @foreach($agents as $one)
                    <div class="col-md-3 col-xs-6 wkyle">
                        <a href="{{ $one->url }}" target="_blank">
                            <img style="height: 58px;width: 153px;" src="{{ asset($one->image) }}" alt="{{ $one->title }}"  title="{{ $one->title }}">
                        </a>
                    </div>
                    @endforeach

                </div>

            </div>
        </div>
    </section>

    <div class="section">
        <div class="container">
            <div class="text-center description block">
                <h1>The Most Important Shrines</h1>
                <p>Know with us the most important and best religious and holy shrines in the Kingdom of Saudi Arabia </p>
            </div>


            <div class="block image-carousel style2 flexslider ltr" data-animation="slide" data-item-width="370" data-item-margin="30">
                <ul class="slides image-box style1 tour-packages">
                    <li>
                        <article class="box animated" data-animation-type="fadeInLeft">
                            <figure>
                                <a href="#"><img src="{{ asset('front/images/tour/packages/3-col/1.jpg') }}" alt=""></a>
                                <figcaption>

                                    <h2 class="caption-title">Quba Mosque</h2>
                                </figcaption>
                            </figure>
                        </article>
                    </li>
                    <li>
                        <article class="box animated" data-animation-type="fadeInDown">
                            <figure>
                                <a href="#"><img src="{{ asset('front/images/tour/packages/3-col/2.jpg') }}" alt=""></a>
                                <figcaption>

                                    <h2 class="caption-title">Baka al-Gharqd </h2>
                                </figcaption>
                            </figure>
                        </article>
                    </li>
                    <li>
                        <article class="box animated" data-animation-type="fadeInRight">

                            <figure>
                                <a href="#"><img src="{{ asset('front/images/tour/packages/3-col/3.jpg') }}" alt=""></a>
                                <figcaption>

                                    <h2 class="caption-title">Laure Thore </h2>
                                </figcaption>
                            </figure>
                        </article>
                    </li>
                    <li>
                        <article class="box animated" data-animation-type="fadeInDown">
                            <figure>
                                <a href="#"><img src="{{ asset('front/images/tour/packages/3-col/2.jpg') }}" alt=""></a>
                                <figcaption>

                                    <h2 class="caption-title">Baka al-Gharqd </h2>
                                </figcaption>
                            </figure>
                        </article>
                    </li>
                    <li>
                        <article class="box animated" data-animation-type="fadeInLeft">
                            <figure>
                                <a href="#"><img src="{{ asset('front/images/tour/packages/3-col/1.jpg') }}" alt=""></a>
                                <figcaption>

                                    <h2 class="caption-title">Quba Mosque</h2>
                                </figcaption>
                            </figure>
                        </article>
                    </li>
                </ul>
            </div>



        </div>
    </div>

    <section>
        <div class="container">
            <div class="row">
                <h1>Partners</h1>
                <div class="investor-slideshow image-carousel style2 investor-list ltr" data-animation="slide" data-item-width="170" data-item-margin="30">
                    <ul class="slides">

                        @foreach($partners as $one)
                        <li>
                            <div class="travelo-box animated" data-animation-type="fadeInUp">
                                <a href="{{ $one->url }}" target="_blank"><img src="{{ asset($one->image) }}" alt="{{ $one->title }}" title="{{ $one->title }}"></a>
                            </div>
                        </li>
                        @endforeach


                    </ul>
                </div>
            </div>
        </div>
    </section>


    <div class="global-map-area section parallax" data-stellar-background-ratio="0.5">
        <div class="container">
            <h1 class="text-center white-color">Testimonials</h1>
            <div class="testimonial style3">
                <ul class="slides ">
                    @foreach($reviews as $one)
                    <li>
                        <div class="author">
                            <a href="javascript:;">
                                <img src="{{ asset($one->image) }}" alt="" width="74" height="74" />
                            </a>
                        </div>
                        <blockquote class="description"> {{ $one->content_en }} </blockquote>
                        <h2 class="name">{{ $one->title }}</h2>
                    </li>
                    @endforeach

                </ul>
            </div>
        </div>
    </div>

    <div class="container section">
        <h2>Photo Gallery</h2>
        <div class="flexslider image-carousel style2 row-2 ltr" data-animation="slide" data-item-width="170" data-item-margin="30">
            <ul class="slides">
                <li>
                    <a href="{{ asset('front/images/style02/1.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/1.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="{{ asset('front/images/style02/7.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/7.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
                <li>
                    <a href="{{ asset('front/images/style02/2.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/2.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="{{ asset('front/images/style02/8.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/8.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
                <li>
                    <a href="{{ asset('front/images/style02/3.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/3.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="{{ asset('front/images/style02/9.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/9.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
                <li>
                    <a href="{{ asset('front/images/style02/4.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/4.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="mages/style02/10.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/10.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
                <li>
                    <a href="{{ asset('front/images/style02/5.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/5.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="{{ asset('front/images/style02/11.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/11.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
                <li>
                    <a href="{{ asset('front/images/style02/6.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/6.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="{{ asset('front/images/style02/12.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/12.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
                <li>
                    <a href="{{ asset('front/images/style02/1.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/1.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                    <a href="{{ asset('front/images/style02/7.png') }}" class="hover-effect galleryimg" data-lightbox="example-set" data-title="">
                        <img src="{{ asset('front/images/style02/7.png') }}" alt="" />
                        <p class="caption">image title</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>


</section>
@stop
